<?php

namespace App\Http\Controllers\wechat;

use Faker\Provider\ar_JO\Text;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
class WechatController extends Controller
{
    public $app;
    public function __construct(){
        $this->app=app('wechat.official_account');
    }
    //微信验证服务端Token
    public function serve(){
        return "abcd";
       // $response = $this->app->server->serve();
// 将响应输出
       // return $response;
      //$response->send();
      //exit; // Laravel 里请使用：return $response;
        $this->message();
    }
    //微信授权登录
    public function oauth(){
        $response =$this->app->oauth->scopes(['snsapi_userinfo']);
        dump($response);
    }
    //用户发送消息处理
    public function message(){
        $this->app->server->push(function ($message) {
            return "您好！欢迎关注我!";
        });

        $response =$this->app->server->serve();
        return $response;
    }
    //公众号菜单
    public function menu(){
        $buttons = [
            [
                "type" => "click",
                "name" => "今日歌曲",
                "key"  => "V1001_TODAY_MUSIC"
            ],
            [
                "name"       => "菜单",
                "sub_button" => [
                    [
                        "type" => "view",
                        "name" => "搜索",
                        "url"  => "http://www.soso.com/"
                    ],
                    [
                        "type" => "view",
                        "name" => "视频",
                        "url"  => "http://v.qq.com/"
                    ],
                    [
                        "type" => "click",
                        "name" => "赞一下我们",
                        "key" => "V1001_GOOD"
                    ],
                ],
            ],
        ];
        $this->app->menu->create($buttons);
    }
}
